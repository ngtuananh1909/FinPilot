# FinPilot AI MVP — Tasks (Implementation Requires Separate G1 Approval)

> Kiro: Treat this as a **proposed dependency plan**, not permission to implement. First inspect repository and Stitch export, present repo-specific delta plan with expected file changes and ask approval. **Do not mark tasks Done unless evidence exists.**

## Phase 0 — plan gate
- [ ] **T00.1** Inspect actual repo, existing code/config, user-provided Stitch files and current Next.js/AWS docs; list reuse vs new work.
- [ ] **T00.2** Prepare implementation plan with task order, costs, risks, dependency/version choices and no destructive actions; **STOP and request G1 approval**.

## Phase 1 — foundation and security
- [ ] **T01.1** After G1: initialize/pin Next.js TypeScript + lint/typecheck/test stack compatible with AWS Amplify SSR. Document versions.
- [ ] **T01.2** Implement strict `.env` validation, Supabase SSR Auth session handling, error system, mobile app shell and loading states.
- [ ] **T01.3** Review candidate SQL, RLS policies, FK ownership and quota function; prepare **separate G2 remote migration approval**, do not run migration yet.
- [ ] **T01.4** Implement DB repository with verified owner context and schema types; RLS adversarial test strategy.
- [ ] **T01.5** Implement standalone pure finance engine: snapshot, exclusion kinds, monthly recurrence/clamp, 45-day projection and reserve simulation; add boundary/property tests.

## Phase 2 — demo and transactions
- [ ] **T02.1** Implement synthetic fixture loader, Guest anonymous auth and idempotent per-user persona clone; **G2 approval needed before any remote seeded write**.
- [ ] **T02.2** Implement 3 distinct email/password demo accounts via manual/safe admin seeding plan; no credentials committed.
- [ ] **T02.3** Implement Transactions CRUD, ownership, snapshot rules and recurring reconciliation.
- [ ] **T02.4** CSV import preview, column mapping, duplicate review, idempotent commit; tests for malformed CSV and repeat upload.
- [ ] **T02.5** Settings profile, reserve, monthly recurring items, estimated variable spend, one active savings goal.

## Phase 3 — primary user experience
- [ ] **T03.1** Integrate Stitch design export after user reviews it. Implement Welcome, persona chooser, login and onboarding.
- [ ] **T03.2** Dashboard real financial summaries and 45-day chart/alerts; empty/error/loading states.
- [ ] **T03.3** Simulator comparison with same baseline and reserve checks; mobile + desktop E2E.

## Phase 4 — actual AI (no mocked demo)
- [ ] **T04.1** Implement capability-aware Gemini/OpenRouter server adapter, `.env` model/base/key, validated tool schemas; contract tests.
- [ ] **T04.2** Implement finance read-only tool handlers and normalized source/assumption provenance; bound tool steps.
- [ ] **T04.3** Implement AI Assistant UI and API, owned conversations/messages, clear unavailable-provider state.
- [ ] **T04.4** Implement AI Vision receipt draft preview + user confirmation, file validation and quotas.
- [ ] **T04.5** Implement budget/goal proposal UI and server-only confirmation with stale/replay protection.

## Phase 5 — secure release
- [ ] **T05.1** Execute lint, typecheck, unit tests, authorized RLS/integration tests and E2E; review code/security and fix regressions.
- [ ] **T05.2** Produce evidence summary, public-demo script, source README and submission artifact preparation checklist.
- [ ] **T05.3** Configure AWS Amplify secrets/runtime/build **after infrastructure approval**; verify AWS credit, billing alerts and auth redirects.
- [ ] **T05.4** Present release plan, expected git push and deployment impact; **STOP for G4 approval**. After approved push to main, verify public app and 3 demo accounts.

## Stop conditions
If any operation requires DB reset, migration, seed/admin creation, deletion, push, PR, merge or deploy, ask for **separate explicit approval**. If AI API credentials not available, finish non-AI tasks and mark AI tests **BLOCKED** rather than pretending PASS. Never mark final Done while live path untested.
